<?php 
    include("inc/header.adm.php");
    $msg = "";
    function getData() {
        $sql = "SELECT * FROM tbl_user";
        $result = $GLOBALS['conn']->query($sql);
        if($result->num_rows > 0 ){
            return $result;
        }
    }
    if (isset($_GET['del'])) {
        $id = $_GET['del'];
        mysqli_query($conn, "DELETE FROM tbl_user WHERE id=$id");
        $msg = "<p style = \"background-color:#099250; color:white;\">User Deleted Successfully</p>";
        header('Refresh:2; url=list_users.php');
    }
?>
            
            <div id="content-wrapper" class="d-flex flex-column">
                <div class="container" style="width:70%; margin:auto; ">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="mb-3">
                                <a href="create_users.php" class="btn btn-success"><i class="fas fa-plus">&nbsp;&nbsp;</i>Add New User</a>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive loan-actions">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <div id="response-alert" class="text-center"> <?=$msg?></div>
                            <thead>
                                <tr>
                                    
                                    <th>S/N</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Phone Number</th>
                                    <th>Email Address</th>
                                    <th>Role</th>
                                    <th>Action</th>                                       
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php 
                                    $result = getData();
                                            
                                        if($result) {
                                            $n=0;
                                            while($users = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?=++$n;?></td>
                                    <td><?=$users['first_name'];?></td>
                                    <td><?=$users['last_name'];?></td>
                                    <td><?=$users['user_phone'];?></td>
                                    <td><?=$users['user_email'];?></td>
                                    <td><?=$users['user_role'];?></td>
                                    <td>
                                        <a href="edit_users.php?edit=<?=$users['id']; ?>" style="color:blue;"><i class="fas fa-pen-alt"></i></a>
                                        <a href="list_users.php?del=<?=$users['id']; ?>" style="color:red;"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                
                                    
                                </tr>
                                <?php
                                      }
                                  }else { echo "<tr><td colspan='12' class='text-center'>No User Record found</td></tr>";}
                                ?>
                            </tbody>
                        </table>
                    </div>
               
            </div>
            
  

    
<?php include("inc/footer.adm.php");?>
    