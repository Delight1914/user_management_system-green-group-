<?php 
    include("inc/header.adm.php"); 
    $msg = "";
    if (isset($_POST['update'])) {
        $id      = $_POST['id'];
        $first_name = $_POST['first_name']; 
        $last_name = $_POST['last_name'];
        $phone = $_POST['phone']; 
        $email = $_POST['email']; 
           
        $sql = "UPDATE tbl_user SET first_name = '$first_name',
                last_name = '$last_name', user_phone = '$phone', user_email = '$email'
                WHERE id='$id'";
        $update = $conn->query($sql);
        
  
        if ($update) {
            $msg = "<p style = \"background-color:#099250; color:white;\">User Update Successfully</p>";
            header('Refresh:2; url=index.php');
        } else {
            $msg = "<p style = \"background-color:#d63333; color:white;\">Could not update User</p>";
        }
  }
?>

    <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">
    <div class="container-fluid">
       
        <div class="container" style="width:50%; margin:auto; ">
        <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-4 text-gray-800 text-align-center">Profile</h1>         
                            
                    </div>
                    <form class="user" method="post" action="<?=$_SERVER["PHP_SELF"];?>">
                        <div id="response-alert"></div>
                        <div id="response-alert" class="text-center"> <?=$msg?></div>

                         <input type="hidden" name="id" value="<?=$_SESSION['id']; ?>">
                        
                
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">First Name:</label>
                                    <input type="text" value="<?=$_SESSION['first_name'];?>" name="first_name" class="form-control form-control-user" id="exampleLastName">
                                </div>
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">Last Name:</label>
                                    <input type="text" value="<?=$_SESSION['last_name'];?>" name="last_name" class="form-control form-control-user"
                                        id="exampleInputEmail" aria-describedby="emailHelp">
                                </div>
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">Phone:</label>
                                    <input type="text" value="<?=$_SESSION['user_phone'];?>" name="phone" class="form-control form-control-user"
                                        id="exampleInputEmail" aria-describedby="emailHelp">
                                </div>
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">Email:</label>
                                    <input type="text" value="<?=$_SESSION['user_email'];?>" name="email" class="form-control form-control-user"
                                        id="exampleInputEmail" aria-describedby="emailHelp">
                                </div>
                                
                                <input type="submit" value="Update" name="update" class="btn btn-success btn-user btn-block">
                                <hr>
                        </div>
                        
                    
                    </form>
        

    </div>
    <!-- /.container-fluid -->

    
</div>
<!-- End of Main Content -->

<?php 
    include("inc/footer.adm.php"); 
?>