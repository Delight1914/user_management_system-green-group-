<?php 
    include("inc/header.adm.php");
    $id  = "";
    $msg = "";

     
    if (isset($_POST['update'])) {
        $id      = $_POST['id'];
        $first_name = $_POST['f_name']; 
        $last_name = $_POST['l_name'];
        $phone = $_POST['u_phone']; 
        $email = $_POST['u_email']; 
        $role =  $_POST['role'];
           
        $sql = "UPDATE tbl_user SET first_name = '$first_name',
                last_name = '$last_name', user_phone = '$phone', user_email = '$email', user_role = '$role'
                WHERE id='$id'";
        $update = $conn->query($sql);
        
  
        if ($update) {
            $msg = "<p style = \"background-color:#099250; color:white;\">User Update Successfully</p>";
            header('Refresh:2; url=list_users.php');
        } else {
            $msg = "<p style = \"background-color:#d63333; color:white;\">Could not update User</p>";
        }
  }

    if (isset($_GET['edit'])) {
        $id = $_GET['edit'];

        $sql =  "SELECT * FROM tbl_user WHERE id=$id";
        $result = $GLOBALS['conn']->query($sql);

        if ($result) {
            while($users=$result->fetch_assoc()){
                $id = $users['id']; 
                $first_name = $users['first_name']; 
                $last_name = $users['last_name'];
                $phone = $users['user_phone']; 
                $email = $users['user_email']; 
                $role =  $users['user_role'];
?>
           
<div id="content-wrapper" class="d-flex flex-column">

    <div class="container" style="width:50%; margin:auto; ">
<!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-4 text-center text-gray-800">Update Users</h1>
                    
            </div>
            <form class="user" method="post" action="<?=$_SERVER["PHP_SELF"];?>">
                <div id="response-alert" class="text-center"> <?=$msg?></div>
                <input type="hidden" name="id" value="<?=$users['id']; ?>">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group mb-5">
                            <label for="" class="form-label">First Name</label>
                            <input type="text" name="f_name" value="<?=isset($first_name)?$first_name:'';?>" class="form-control form-control-user" id="exampleFirstName"
                                placeholder="First Name">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-5">
                            <label for="" class="form-label">Last Name</label>
                            <input type="text" name="l_name" value="<?=isset($last_name)?$last_name:'';?>" class="form-control form-control-user" id="exampleLastName"
                                placeholder="Last Name">
                        </div>
                    </div>
                </div>

                <div class="form-group mb-5">
                    <label for="" class="form-label">Phone Number</label>
                    <input type="text" name="u_phone" value="<?=isset($phone)?$phone:'';?>" class="form-control form-control-user" id="examplePhone"
                        placeholder="Phone Number">
                </div>

                <div class="form-group mb-5">
                    <label for="" class="form-label">Email</label>
                    <input type="email" name="u_email" value="<?=isset($email)?$email:'';?>" class="form-control form-control-user" id="exampleInputEmail"
                        placeholder="Email">
                </div>
                <div class="form-group mb-5">
                    <label for="" class="form-label">Role</label>
                    <select class="form-control" id="exampleFormControlSelect1" name="role" >
                        <option value="">--</option>
                        <option value="Admin" <?=isset($role)?$role:'';?>>Admin</option>
                        <option value="User"<?=isset($role)?$role:'';?>>User</option>
                    </select>
                </div>
                
               <?php }}} else{echo "<script>window.location = 'list_users.php'; </script>";}?>
                
                <input type="submit" value="Update User" name="update" class="btn btn-success btn-user btn-block">
                
                <hr>
            
            </form>
        </div>
    </div>
      
</div>
    

<?php include("inc/footer.adm.php");?>
