<?php 
    include("inc/header.adm.php");

    $msg = "";
    if(isset($_POST['create'])) {
        $first_name = htmlspecialchars(strip_tags($_POST['f_name']));
        $last_name = htmlspecialchars(strip_tags($_POST['l_name']));
        $phone = htmlspecialchars(strip_tags($_POST['u_phone']));
        $email = htmlspecialchars(strip_tags($_POST['u_email']));
        $password = htmlspecialchars(strip_tags($_POST['u_pass']));
        $conf_password = htmlspecialchars(strip_tags($_POST['u_conf_pass']));
        $role = htmlspecialchars(strip_tags($_POST['role']));

        if(!empty($first_name) && !empty($last_name) && !empty($email) && !empty($password) && !empty($conf_password) && !empty($role)){
            if($password !== $conf_password){
                $msg = "<p style = \"background-color:#d63333; color:white;\">Password not matched</p>";
            } else{
                $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
                $query = "INSERT INTO tbl_user (first_name, last_name, user_phone, user_email, user_password, user_role)
                            VALUES ('$first_name', '$last_name', '$phone', '$email', '$hashed_pass', '$role')";
               $result = $conn->query($query);
               if($result) {
                   $msg = "<p style = \"background-color:#099250; color:white;\">User Created Successfully</p>";
                   header('Refresh:2; url=list_users.php');

               } else{
                   $msg = "<p style = \"background-color:#d63333; color:white;\">Unable to create user. Database Error<?p>";
               }
            }
        } else{
            $msg = "<p style = \"background-color:#d63333; color:white;\">Please fill all required fields</p>";
        }
  
    }
    
?>
            
            <!-- <div id="right-sec" class="col-md-12 col-lg-12"> -->
    <div id="content-wrapper" class="d-flex flex-column">

        <div class="container" style="width:50%; margin:auto; ">
            <div class="row">
                <div class="col-sm-6">
                    <div class="mb-3">
                        <a href="list_users.php" class="btn btn-success"><i class="fas fa-plus">&nbsp;&nbsp;</i>List all Users</a>
                    </div>
                </div>
            </div>
        <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                                <h1 class="h3 mb-4 text-center text-gray-800">Create Users</h1>
                            
                    </div>
                    <form class="user" method="post" action="<?=$_SERVER["PHP_SELF"];?>">
                        <div id="response-alert" class="text-center"> <?=$msg?></div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">First Name</label>
                                    <input type="text" name="f_name" value="<?=isset($first_name)?$first_name:'';?>" class="form-control form-control-user" id="exampleFirstName"
                                        placeholder="First Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">Last Name</label>
                                    <input type="text" name="l_name" value="<?=isset($last_name)?$last_name:'';?>" class="form-control form-control-user" id="exampleLastName"
                                        placeholder="Last Name">
                                </div>
                            </div>
                        </div>

                        <div class="form-group mb-5">
                            <label for="" class="form-label">Phone Number</label>
                            <input type="text" name="u_phone" value="<?=isset($phone)?$phone:'';?>" class="form-control form-control-user" id="examplePhone"
                                placeholder="Phone Number">
                        </div>

                        <div class="form-group mb-5">
                            <label for="" class="form-label">Email</label>
                            <input type="email" name="u_email" value="<?=isset($email)?$email:'';?>" class="form-control form-control-user" id="exampleInputEmail"
                                placeholder="Email">
                        </div>
                        <div class="form-group mb-5">
                            <label for="" class="form-label">Role</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="role" >
                                <option value="">--</option>
                                <option value="Admin" <?=isset($role)?$role:'';?>>Admin</option>
                                <option value="User"<?=isset($role)?$role:'';?>>User</option>
                            </select>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">New Password:</label>
                                    <input type="password" class="form-control form-control-user"
                                        id="examplePassword" aria-describedby="emailHelp"
                                        placeholder="New password" name="u_pass" value="<?=isset($password)?$password:'';?>">
                                </div>                               
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-5">
                                    <label for="" class="form-label">Confirm Password:</label>
                                    <input type="password" class="form-control form-control-user"
                                        id="examplePassword" aria-describedby="emailHelp"
                                        placeholder="Confirm-password" name="u_conf_pass" value="<?=isset($conf_password)?$conf_password:'';?>">
                                </div>
                            </div>
                        </div>
                        
                        
                        <input type="submit" value="Create User" name="create" class="btn btn-success btn-user btn-block">
                        
                        <hr>
                    
                    </form>
                </div>
            </div>
              
            </div>
            
  
    
<?php include("inc/footer.adm.php");?>
    