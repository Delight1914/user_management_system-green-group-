
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap-5/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery.validation/jquery.validate.min.js"></script>
<script src="assets/js/sb-admin-2.min.js"></script>
<!-- <script src="assets/js/views/view.auth.js"></script> -->