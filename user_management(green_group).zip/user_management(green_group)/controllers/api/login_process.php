<?php
    session_start();
    include "../config/database.php";

    
    $msg = "";
    if(isset($_POST['login'])) {
        $u_email = htmlspecialchars(strip_tags($_POST['u_email']));
        $u_pass = htmlspecialchars(strip_tags($_POST['u_pass']));
        
        if(!empty($u_email) && !empty($u_pass)){
            $search_email = "SELECT * FROM tbl_user WHERE user_email='$u_email'";
            $search_result = $conn->query($search_email);
            if($search_result->num_rows > 0){
                while($row = $search_result->fetch_assoc()) {
                    $email = $row['user_email'];
                    $db_pass = $row['user_password'];
                    $verify_pass = password_verify($u_pass, $db_pass);
                    if($verify_pass){
                        if($row["role"] == "Admin") {
                            // $_SESSION['first_name'] = $row["first_name"];
                            // $_SESSION['last_name'] = $row["last_name"];
                            // $_SESSION['user_phone'] = $row["user_phone"];
                            // $_SESSION['user_email'] = $row["user_email"];
                            // $_SESSION['role'] = $row["role"];
                            header('Location: ../../test.php');
                        }
                        else {
                            $_SESSION['first_name'] = $row["first_name"];
                            $_SESSION['last_name'] = $row["last_name"];
                            $_SESSION['user_phone'] = $row["user_phone"];
                            $_SESSION['user_email'] = $row["user_email"];
                            $_SESSION['role'] = $row["role"];
                            header('Location: ../../test1.php');
                        }
                    }
				
				}
               
            } else{
                echo "could not find email";
            }
            
        } else{
            $msg = "Please fill all required fields";
        }
  
    } else{
        $msg = "Access Denied";
    }

?>