<?php
    include_once("inc/header.nav.php");
    
    $msg = "";
    if(isset($_POST['login'])) {
        $u_email = htmlspecialchars(strip_tags($_POST['u_email']));
        $u_pass = htmlspecialchars(strip_tags($_POST['u_pass']));
        
        if(!empty($u_email) && !empty($u_pass)){
            $search_email = "SELECT * FROM tbl_user WHERE user_email='$u_email'";
            
            $search_result = $conn->query($search_email);
            if($search_result->num_rows > 0){
    
                while($row = $search_result->fetch_assoc()) {
                    $email = $row['user_email'];
                    $db_pass = $row['user_password'];
                    $verify_pass = password_verify($u_pass, $db_pass);
                    if($verify_pass){
                        if($row["user_role"] == "Admin") {
                            $_SESSION['id'] = $row["id"];
                            $_SESSION['first_name'] = $row["first_name"];
                            $_SESSION['last_name'] = $row["last_name"];
                            $_SESSION['user_phone'] = $row["user_phone"];
                            $_SESSION['user_email'] = $row["user_email"];
                            $_SESSION['ADMIN'] = $row["user_role"];
                            $msg = "<p style = \"background-color:#099250; color:white;\">Login successful</p>";
                            header('Refresh:2; url=Admin/index.php');
                        }
                        else {
                            $_SESSION['id'] = $row["id"];
                            $_SESSION['first_name'] = $row["first_name"];
                            $_SESSION['last_name'] = $row["last_name"];
                            $_SESSION['user_phone'] = $row["user_phone"];
                            $_SESSION['user_email'] = $row["user_email"];
                            $_SESSION['USER'] = $row["user_role"];
                            $msg = "<p style = \"background-color:#099250; color:white;\">>Login successful</p>";
                            header('Refresh:2; url=User/index.php');
                        }
                    } else{
                        $msg = "<p style = \"background-color:#d63333; color:white;\">Password does not match email</p>";
                    }
				
				}
               
            } else{
                $msg = "<p style = \"background-color:#d63333; color:white;\">could not find email</p>";
            }
            
        } else{
            $msg = "<p style = \"background-color:#d63333; color:white;\">Please fill all required fields</p>";
        }
  
    } 
?>
	

    <div class="container">

        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9 my-5">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                    </div>
                                    <form class="user" method="post" action="<?=$_SERVER["PHP_SELF"];?>">
                                                                     
                                        <div id="response-alert" class="text-center"> <?=$msg?></div>
                                        
                                        <div class="form-group">
                                            <input type="email" name="u_email" class="form-control form-control-user"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Enter Email Address..." required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="u_pass" class="form-control form-control-user"
                                                id="exampleInputPassword" placeholder="Password" required>
                                        </div>
                                        
                                        <input type="submit" value="Login" name="login" data-loading-text="Please wait..." class="btn btn-success btn-user btn-block">
                                        
                                        <hr>
                                       
                                    </form>                                                                                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include_once("inc/footer.nav.php")?>