A User management system designed and developed by SIDEHUSTLE BACKEND PHP 4.0 - GREEN GROUP

Create a database and import the sql file contained in the root folder

Login Credentials

Admin
email - admin@gmail.com
Password - admin


User 
email - user@gmail.com
password - user