document.getElementById("side-bar-drop").addEventListener("click", function () {
    document.querySelector("#side-bar").classList.toggle("hide-bar");
    // document.getElementById("right-sec").classList.toggle("transparency");
});
