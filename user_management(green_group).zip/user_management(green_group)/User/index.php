<?php include("inc/header.usr.php");?>
            
            <!-- <div id="right-sec" class="col-md-12 col-lg-12"> -->
            <div id="content-wrapper" class="d-flex flex-column">

                <div class="row">
                    <main>
                        <h2 class="text-center">Dashboard</h2>
                      
                    </main>
                </div>
                
            </div>
            
  

    
<?php include("inc/footer.usr.php");?>
    