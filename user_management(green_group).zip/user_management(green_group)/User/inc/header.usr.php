<?php
     ob_start(); session_start(); date_default_timezone_set('Africa/Lagos'); // WAT
     include_once("../controllers/config/database.php"); 
     
    if(!isset($_SESSION["USER"])){
        header("location: ../login.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous">
    <title>User|Dash Board</title>
</head>
<body>
   <div id="wrapper" class="fs-6">
    <header class="">
        <div class="bg-success py-2 px-3 mb-3 top">
            <div class="search-bar">
                <button id="side-bar-drop" class="btn rounded-circle text-white">&#9776;</button>
            </div>
            
            <p class="text-white"><?=$_SESSION['first_name']. ' ' .$_SESSION['last_name'];?><img class="user" src="../assets/images/man.png" alt="user-icon" title="user-icon">
            <br><?=$_SESSION['user_email'];?>
            <br>Logged in as: <?=$_SESSION['USER'];?>
            </p>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <ul id="side-bar" class="col-sm-3 col-lg-3 col-md-3 bg-success bg-l">
                <div class="logo-cont px-2 py-3">
                    <h1 class="logo text-white">G<span class="text-warning display-4 fw-bold">A</span>C</h1>
                    <p class="text-white">Greenacademy corporation</p>
                </div>

                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-fw fa-home"></i>
                        <span>Home</span></a>
                </li>

                <hr class="sidebar-divider text-light my-0">
                
                <!-- Heading -->
                <div class="sidebar-heading text-light pt-5">
                        ACCOUNT MANAGEMENT
                    </div>
                    <hr class="sidebar-divider text-light">


                    <hr class="sidebar-divider text-light my-0">



                    <!-- Nav Item - Tables -->
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-alt"></i>
                            <span>Profile</span></a>
                    </li>
                
                <!-- Divider -->
                <hr class="sidebar-divider text-light d-none d-md-block">

                <li class="nav-item">
                    <a class="nav-link" href="logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span></a>
                </li>
         
            </ul> 
            